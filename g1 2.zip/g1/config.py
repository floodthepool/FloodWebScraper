EMAIL = 'guitwebscrap@gmail.com'
PASSWORD = '8SwG6z3L4KLc0$Cv2'