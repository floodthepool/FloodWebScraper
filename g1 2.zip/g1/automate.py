import check3
import craig
import craig2
import schedule

check3.check_words()
craig.check_craig()
craig2.check_craig()
schedule.every(15).seconds.do(check3.check_words)
schedule.every(15).seconds.do(craig.check_craig)
schedule.every(15).seconds.do(craig2.check_craig)

while True:
    schedule.run_pending()
