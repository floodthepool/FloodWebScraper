import check
import schedule

check.check_words()
schedule.every(1).minutes.do(check.check_words)

