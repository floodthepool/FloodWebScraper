EMAIL = 'email@email.com'
PASSWORD = '********'